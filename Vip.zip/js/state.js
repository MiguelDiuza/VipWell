// --- NAVIGATION STATE ---
let currentState = {
    view: 'home',
    productFilter: 'all'
};

const mainContent = document.getElementById('app-content');
