// --- DATA STORE ---
const appData = {
    products: [
        {
            id: 'p1',
            category: 'inyeccion',
            name: 'Serie VW-500 Hidráulica',
            model: 'VW-500H',
            manufacturer: 'VIPWELL Industrial',
            year: '2023',
            origin: 'China',
            tagline: 'Potencia Clásica para Alta Demanda',
            image: 'recursos/machine/machine1.jpg',
            performanceImage: 'recursos/machine/machine1.jpg',
            desc: 'Sistema de inyección hidráulica de alta precisión con unidad de cierre reforzada. Ideal para preformas PET y tapas.',
            specs: {
                tonnage: '500T',
                cycleTime: '4.2s',
                power: '45kW',
                weight: '12T',
                shotVolume: '2500 cm³',
                screwDiameter: '70mm'
            },
            metrics: [85, 70, 90, 95, 80],
            video: 'recursos/machine/blanco.mp4',
        },
        {
            id: 'p2',
            category: 'inyeccion',
            name: 'Serie E-Motion Eléctrica',
            model: 'EM-280E',
            manufacturer: 'VIPWELL Tech',
            year: '2024',
            origin: 'Alemania',
            tagline: 'Eficiencia Energética Superior',
            image: 'recursos/machine/machine2.jpg',
            performanceImage: 'recursos/machine/machine2.jpg',
            desc: 'Máquina totalmente eléctrica. Reduce el consumo energético hasta un 60%. Silenciosa, limpia y extremadamente precisa.',
            specs: {
                tonnage: '280T',
                cycleTime: '3.8s',
                power: '18kW',
                weight: '8T',
                shotVolume: '1500 cm³',
                screwDiameter: '55mm'
            },
            metrics: [95, 90, 98, 95, 75],
            video: 'recursos/machine/videoG.mp4',
        },
        {
            id: 'p3',
            category: 'extrusion',
            name: 'Extrusora EX-Pro Tubería',
            model: 'EXP-110',
            manufacturer: 'VIPWELL Extrusion',
            year: '2023',
            origin: 'Italia',
            tagline: 'Producción Continua Sin Interrupciones',
            image: 'recursos/machine/machine3.jpg',
            performanceImage: 'recursos/machine/machine3.jpg',
            desc: 'Línea completa para extrusión de tubería PVC/HDPE. Incluye tanque de enfriamiento y unidad de corte automatizada.',
            specs: {
                tonnage: 'N/A',
                cycleTime: 'Continua',
                power: '110kW',
                weight: '15T',
                outputRate: '450 kg/h',
                pipeRange: '16-630mm'
            },
            metrics: [80, 85, 75, 85, 95],
            video: 'recursos/machine/gris.mp4',
        },
        {
            id: 'p4',
            category: 'robotica',
            name: 'Brazo Robótico R-Axix 6',
            model: 'RA6-PRO',
            manufacturer: 'VIPWELL Robotics',
            year: '2024',
            origin: 'Japón',
            tagline: 'Automatización de Pick & Place',
            image: 'recursos/machine/machine4.webp',
            performanceImage: 'recursos/machine/machine4.webp',
            desc: 'Brazo robótico de 6 ejes para extracción de piezas y paletizado. Integración nativa con líneas de inyección y extrusión.',
            specs: {
                tonnage: 'Payload 10kg',
                cycleTime: '0.5s',
                power: '3kW',
                weight: '200kg',
                reach: '1850mm',
                repeatability: '±0.02mm'
            },
            metrics: [90, 98, 95, 99, 85],
            video: 'recursos/machine/naranja.mp4',
        },
        {
            id: 'p5',
            category: 'extrusion',
            name: 'Línea de Perfilería Window',
            model: 'LPW-85',
            manufacturer: 'VIPWELL Profiles',
            year: '2023',
            origin: 'Austria',
            tagline: 'Precisión para Construcción',
            image: 'recursos/machine/machine5.jpg',
            performanceImage: 'recursos/machine/machine5.jpg',
            desc: 'Especializada en perfiles complejos para ventanas y marcos. Calibración al vacío de alta velocidad.',
            specs: {
                tonnage: 'N/A',
                cycleTime: 'Continua',
                power: '85kW',
                weight: '10T',
                outputRate: '320 kg/h',
                profileWidth: '40-160mm'
            },
            metrics: [88, 80, 85, 92, 90],
            video: 'recursos/machine/rojo.mp4',
        }
    ],
    metricsLabels: [
        'Eficiencia General',
        'Velocidad Ciclo',
        'Ahorro Energía',
        'Precisión',
        'Durabilidad'
    ]
};


const cicloIntegralData = [
    {
        place: 'Internacional',
        title: 'Sourcing',
        title2: 'Global',
        description: 'No nos limitamos a nuestro stock. Localizamos, negociamos y transportamos maquinaria específica desde cualquier parte del mundo (Asia, América o Europa).',
        image: 'recursos/1.png'
    },
    {
        place: 'Hub Logístico - Madrid',
        title: 'Maquila',
        title2: 'Plásticos',
        description: '¿No desea invertir en activos fijos? Ponemos nuestra planta en Europa a su disposición. Utilizamos nuestra propia maquinaria instalada para fabricar sus piezas plásticas.',
        image: 'recursos/2.png'
    },
    {
        place: 'Planta de Producción',
        title: 'Venta',
        title2: 'Maquinaria',
        description: 'Nuestro equipo de ingenieros europeos garantiza una instalación impecable y la capacitación técnica necesaria para maximizar su ROI.',
        image: 'recursos/3.png'
    },
    {
        place: 'Confianza y respaldo',
        title: 'Consultoría',
        title2: 'Procesos',
        description: 'Analizamos sus necesidades productivas, presupuesto y objetivos para diseñar la hoja de ruta ideal. Le asesoramos sobre importar, fabricar o maquilar, garantizando la inversión.',
        image: 'recursos/4.png'
    }
];

